//
//  crimeDetail.swift
//  ClassProject
//
//  Created by Anuj Kamasamudram on 3/19/23.
//

import SwiftUI

struct
